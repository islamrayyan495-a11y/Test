// Netlify Function — receives { email } from the landing page form and
// sends a confirmation email to that address via Resend's API.
// Deployed automatically at /api/subscribe (see the `config` export below).

export default async (req) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  let email;
  try {
    const body = await req.json();
    email = (body.email || "").trim();
  } catch {
    return Response.json({ error: "Invalid request body" }, { status: 400 });
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailPattern.test(email)) {
    return Response.json({ error: "Enter a valid email address" }, { status: 400 });
  }

  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.error("RESEND_API_KEY is not set in this site's environment variables");
    return Response.json(
      { error: "Email sending isn't configured yet" },
      { status: 500 }
    );
  }

  // Resend's shared test sender. It can only deliver to the email address
  // tied to your own Resend account — fine for trying this out, not for
  // real subscribers. Once you verify your own domain in Resend
  // (Domains -> Add Domain), swap this for something like
  // "Fairwind <hello@yourdomain.com>".
  const FROM_ADDRESS = "Fairwind <onboarding@resend.dev>";

  const welcomeHtml = `
    <div style="font-family: sans-serif; max-width: 480px; margin: 0 auto; color:#141F1D; line-height:1.6;">
      <p>Hey,</p>
      <p>You're on the list for <strong>Fairwind</strong> early access.</p>
      <p>We'll email you the moment it's ready &mdash; you'll be one of the first to try it. No spam between now and then, just this one email.</p>
      <p>&mdash; The Fairwind team</p>
    </div>
  `;

  try {
    const sendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: FROM_ADDRESS,
        to: email,
        subject: "You're on the Fairwind list",
        html: welcomeHtml,
      }),
    });

    if (!sendRes.ok) {
      const errText = await sendRes.text();
      console.error("Resend error:", errText);
      return Response.json(
        { error: "Could not send the confirmation email" },
        { status: 502 }
      );
    }

    // Optional: also notify the site owner that someone signed up.
    // Set OWNER_EMAIL in Netlify's environment variables to enable this.
    const ownerEmail = process.env.OWNER_EMAIL;
    if (ownerEmail) {
      fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: FROM_ADDRESS,
          to: ownerEmail,
          subject: "New Fairwind waitlist signup",
          html: `<p>${email} just joined the Fairwind waitlist.</p>`,
        }),
      }).catch((err) => console.error("Owner notification failed:", err));
    }

    return Response.json({ success: true });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Something went wrong" }, { status: 500 });
  }
};

export const config = {
  path: "/api/subscribe",
};
