# Fairwind — landing page starter

"Fairwind" is a placeholder product (a cash-flow forecasting tool for
freelancers) so there's real, specific copy to work from instead of lorem
ipsum. Swap the name and copy in `index.html` for your actual product —
the layout, form, and email function will keep working as-is.

## Files

- `index.html` — the landing page. HTML, CSS, and JS all in one file.
- `netlify/functions/subscribe.mjs` — serverless function that sends a
  confirmation email to whoever submits the form.
- `netlify.toml` — tells Netlify where to find the function.

## Make the confirmation email actually send

The form and page work the moment you deploy, but sending real email
needs one free account:

1. Create a free account at resend.com.
2. Grab an API key from the Resend dashboard.
3. In your Netlify site: **Site settings → Environment variables** → add
   `RESEND_API_KEY` with that key.
4. *(Optional)* Add an `OWNER_EMAIL` variable with your own address to get
   a notification every time someone signs up.
5. By default the function sends from `onboarding@resend.dev`, Resend's
   shared test address — it can only deliver to the email tied to your
   own Resend account. To email real subscribers, verify your own domain
   in Resend (**Domains → Add Domain**) and update the `FROM_ADDRESS`
   constant near the top of `subscribe.mjs`.

## Deploy

Drag this whole folder onto netlify.com/drop, or push it to a GitHub repo
and connect it in Netlify. The function deploys automatically alongside
the page — no separate step needed.
